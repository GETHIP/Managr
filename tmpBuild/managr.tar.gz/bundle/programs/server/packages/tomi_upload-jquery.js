(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Uploader, bytesToSize;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tomi:upload-jquery'] = {};

})();
