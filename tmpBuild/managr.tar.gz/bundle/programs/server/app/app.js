var require = meteorInstall({"lib":{"routes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/routes.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var main = "main";                                                                                                    // 1
                                                                                                                      //
var blogsSection = FlowRouter.group({                                                                                 // 3
    name: "blogs",                                                                                                    // 4
    prefix: ""                                                                                                        // 5
});                                                                                                                   // 3
// Used by all URLs beginning with /assignments                                                                       //
var assignmentSection = FlowRouter.group({                                                                            // 8
    name: "assignments",                                                                                              // 9
    prefix: "/assignments"                                                                                            // 10
});                                                                                                                   // 8
var profileSection = FlowRouter.group({                                                                               // 12
    name: "profiles",                                                                                                 // 13
    profiles: "/profiles"                                                                                             // 14
});                                                                                                                   // 12
var attendanceSection = FlowRouter.group({                                                                            // 16
    name: "attendance",                                                                                               // 17
    profiles: "/attendance"                                                                                           // 18
});                                                                                                                   // 16
blogsSection.route('/', {                                                                                             // 20
    name: 'home',                                                                                                     // 21
    action: function action() {                                                                                       // 22
        BlazeLayout.render(main, { content: 'blogMain' });                                                            // 23
    }                                                                                                                 // 24
});                                                                                                                   // 20
blogsSection.route('/login', {                                                                                        // 26
    name: 'login',                                                                                                    // 27
    action: function action() {                                                                                       // 28
        BlazeLayout.render(main, { content: 'blogMain' });                                                            // 29
    }                                                                                                                 // 30
});                                                                                                                   // 26
                                                                                                                      //
blogsSection.route('/blogs/:blog_id', {                                                                               // 33
    name: 'blogs',                                                                                                    // 34
    action: function action(params) {                                                                                 // 35
        BlazeLayout.render(main, { content: 'postPage' });                                                            // 36
    }                                                                                                                 // 37
});                                                                                                                   // 33
blogsSection.route('/testBlogs', {                                                                                    // 39
    name: 'testBlogs',                                                                                                // 40
    action: function action() {                                                                                       // 41
        BlazeLayout.render('testInsertData');                                                                         // 42
    }                                                                                                                 // 43
});                                                                                                                   // 39
                                                                                                                      //
assignmentSection.route("/", {                                                                                        // 46
    name: "allAssignments",                                                                                           // 47
    action: function action() {                                                                                       // 48
        BlazeLayout.render(main, { content: "studentsAllAssignments" });                                              // 49
    }                                                                                                                 // 50
});                                                                                                                   // 46
assignmentSection.route("/all", {                                                                                     // 52
    name: "allAssignments",                                                                                           // 53
    action: function action() {                                                                                       // 54
        BlazeLayout.render(main, {                                                                                    // 55
            content: "studentsAllAssignments"                                                                         // 56
        });                                                                                                           // 55
    }                                                                                                                 // 58
});                                                                                                                   // 52
// Information on a single assignment                                                                                 //
assignmentSection.route("/single/:id", {                                                                              // 61
    name: "singleAssignment",                                                                                         // 62
    action: function action(params) {                                                                                 // 63
        BlazeLayout.render(main, {                                                                                    // 64
            content: "singleAssignment"                                                                               // 65
        });                                                                                                           // 64
    }                                                                                                                 // 67
});                                                                                                                   // 61
assignmentSection.route("/edit/single/:id", {                                                                         // 69
    name: "editSingleAssignment",                                                                                     // 70
    action: function action(params) {                                                                                 // 71
        BlazeLayout.render(main, {                                                                                    // 72
            content: "editSingleAssignment"                                                                           // 73
        });                                                                                                           // 72
    }                                                                                                                 // 75
});                                                                                                                   // 69
assignmentSection.route('/edit/new', {                                                                                // 77
    name: "newAssignment",                                                                                            // 78
    action: function action(params) {                                                                                 // 79
        BlazeLayout.render(main, {                                                                                    // 80
            content: "newAssignment"                                                                                  // 81
        });                                                                                                           // 80
    }                                                                                                                 // 83
});                                                                                                                   // 77
                                                                                                                      //
assignmentSection.route('/grades', {                                                                                  // 86
    name: "viewAllGrades",                                                                                            // 87
    action: function action() {                                                                                       // 88
        BlazeLayout.render(main, {                                                                                    // 89
            content: "viewAllGrades"                                                                                  // 90
        });                                                                                                           // 89
    }                                                                                                                 // 92
});                                                                                                                   // 86
                                                                                                                      //
assignmentSection.route('/viewAll', {                                                                                 // 95
    name: "viewAllAssignments",                                                                                       // 96
    action: function action() {                                                                                       // 97
        BlazeLayout.render(main, {                                                                                    // 98
            content: "viewAllAssignTable"                                                                             // 99
        });                                                                                                           // 98
    }                                                                                                                 // 101
});                                                                                                                   // 95
                                                                                                                      //
// Spreadsheet of grades                                                                                              //
assignmentSection.route("/edit/grades", {                                                                             // 105
    name: "editGrades",                                                                                               // 106
    action: function action() {                                                                                       // 107
        BlazeLayout.render(main, {                                                                                    // 108
            content: "editGrades"                                                                                     // 109
        });                                                                                                           // 108
    }                                                                                                                 // 111
});                                                                                                                   // 105
profileSection.route("/profile/:id", {                                                                                // 113
    action: function action(params, queryParams) {                                                                    // 114
        BlazeLayout.render("Profile", {                                                                               // 115
            body: "aboutme",                                                                                          // 116
            attendanceBody: "attendanceBody",                                                                         // 117
            assignmentsBody: "assignmentsBody",                                                                       // 118
            editAboutMe: "editAboutMe"                                                                                // 119
        });                                                                                                           // 115
    }                                                                                                                 // 121
});                                                                                                                   // 113
                                                                                                                      //
profileSection.route("/profile/edit/:id", {                                                                           // 124
    action: function action(parmas, queryParams) {                                                                    // 125
        BlazeLayout.render("Profile", { body: "profileEdit", attendance: "attendance", assignments: "assignments" });
    }                                                                                                                 // 127
});                                                                                                                   // 124
                                                                                                                      //
attendanceSection.route("/attendance/edit/:id", {                                                                     // 130
    action: function action(params, queryParams) {                                                                    // 131
        BlazeLayout.render("attendanceUpdate", { updateAttendance: "updateAttendance" });                             // 132
    }                                                                                                                 // 133
});                                                                                                                   // 130
                                                                                                                      //
FlowRouter.route("/assignments/:id", {                                                                                // 136
    action: function action(params, queryParams) {                                                                    // 137
        BlazeLayout.render("Profile", { assignmentsBody: "assignmentsBody" });                                        // 138
    }                                                                                                                 // 139
});                                                                                                                   // 136
                                                                                                                      //
profileSection.route("/profiles", {                                                                                   // 142
    action: function action(params, queryParams) {                                                                    // 143
        BlazeLayout.render(main, { content: 'ProfilesTable' });                                                       // 144
        //BlazeLayout.render(main, { content: 'assignmentsBody' });                                                   //
    }                                                                                                                 // 146
});                                                                                                                   // 142
                                                                                                                      //
FlowRouter.route("/reports", {                                                                                        // 149
    action: function action(params, queryParams) {                                                                    // 150
        BlazeLayout.render("Profile", { body: "reports" });                                                           // 151
    }                                                                                                                 // 152
});                                                                                                                   // 149
                                                                                                                      //
FlowRouter.route('/blogs/:year/:month', {                                                                             // 155
    name: 'archives',                                                                                                 // 156
    action: function action(params) {                                                                                 // 157
        BlazeLayout.render(main, { content: 'archives' });                                                            // 158
    }                                                                                                                 // 159
});                                                                                                                   // 155
                                                                                                                      //
FlowRouter.route('/createPost', {                                                                                     // 162
    name: 'createPost',                                                                                               // 163
    action: function action() {                                                                                       // 164
        BlazeLayout.render(main, { content: 'createPost' });                                                          // 165
    }                                                                                                                 // 166
});                                                                                                                   // 162
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"assignments.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/assignments.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Assignments:function(){return Assignments}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});// Importing mongo for the creation of a collection Assignments
                                                                                                                      // 2
                                                                                                                      //
// An exported constant Mongo Collection object Assigments                                                            //
var Assignments = new Mongo.Collection('Assignments');                                                                // 5
                                                                                                                      //
// A constant of the number of milliseconds in a week (60 * 60 * 24 * 7 * 1000)                                       //
var milliseconds = 604800000;                                                                                         // 8
                                                                                                                      //
Assignments.allow({                                                                                                   // 10
    insert: function insert() {                                                                                       // 11
        return true;                                                                                                  // 12
    }                                                                                                                 // 13
});                                                                                                                   // 10
                                                                                                                      //
// A schema that acts as the required data type format for the Assignments collection                                 //
AssignmentSchema = new SimpleSchema({                                                                                 // 17
    // Assignments title                                                                                              //
    title: {                                                                                                          // 19
        type: String,                                                                                                 // 20
        label: "Title",                                                                                               // 21
        optional: false                                                                                               // 22
    },                                                                                                                // 19
    // Assignment description                                                                                         //
    description: {                                                                                                    // 25
        type: String,                                                                                                 // 26
        label: "Description",                                                                                         // 27
        optional: false                                                                                               // 28
    },                                                                                                                // 25
    // Date assignment is due                                                                                         //
    dueDate: {                                                                                                        // 31
        type: Date,                                                                                                   // 32
        label: "Due Date",                                                                                            // 33
        optional: false                                                                                               // 34
        /*autoValue: function() {                                                                                     //
            // A week ahead of today by default                                                                       //
            return new Date() + milliseconds;                                                                         //
        }*/                                                                                                           //
    },                                                                                                                // 31
    // Instructor that assigned the assignment                                                                        //
    assigner: {                                                                                                       // 41
        type: String,                                                                                                 // 42
        label: "Assigner",                                                                                            // 43
        autoform: {                                                                                                   // 44
            type: 'hidden'                                                                                            // 45
        },                                                                                                            // 44
        optional: false                                                                                               // 47
    },                                                                                                                // 41
    // Date the assignment was created                                                                                //
    dateAssigned: {                                                                                                   // 50
        type: Date,                                                                                                   // 51
        label: "Date Assigned",                                                                                       // 52
        autoform: {                                                                                                   // 53
            type: 'hidden'                                                                                            // 54
        },                                                                                                            // 53
        autoValue: function autoValue() {                                                                             // 56
            // Automatically set to today                                                                             //
            return new Date();                                                                                        // 58
        },                                                                                                            // 59
        optional: true                                                                                                // 60
    },                                                                                                                // 50
    // Points the assignment is worth                                                                                 //
    pointsPossible: {                                                                                                 // 63
        type: Number,                                                                                                 // 64
        label: "Points Possible",                                                                                     // 65
        optional: false                                                                                               // 66
    }                                                                                                                 // 63
});                                                                                                                   // 17
                                                                                                                      //
// Binding the rules of the schema to the Assignments collection                                                      //
Assignments.attachSchema(AssignmentSchema);                                                                           // 71
                                                                                                                      //
// TEST DATA                                                                                                          //
// db.Assignments.insert([{title:"Bubble Sort Algorithm",description:"Write a Java algorithm that sorts random elements using the bubble sort method.",dueDate:new Date(),assigner:"abc",assignedStudents:["abcd","abcde","abcdef"],dateAssigned:new Date(),pointsPossible:100},{title:"Radix Sort Algorithm",description:"Write a Java algorithm that sorts random elements using the radix sort method",dueDate:new Date(),assigner:"abcdefg",assignedStudents:["abcdefgh","abcdefghi","abcdefghij","abcdefghijk"],dateAssigned:new Date(),pointsPossible:140},{title:"Navigation Bar Design",description:"Create a simple navigation bar with at least 5 links.",dueDate:new Date(),assigner:"abcdefghijkl",assignedStudents:["abcdefghijklm","abcdefghijklmn","abcdefghijklmno","abcdefghijklmnop","abcdefghijklmnopq"],dateAssigned:new Date(),pointsPossible:65}]);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"blogPosts.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/blogPosts.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Posts:function(){return Posts}});var Posts = new Mongo.Collection('Posts');                            // 1
                                                                                                                      //
Comment = new SimpleSchema({                                                                                          // 3
    text: {                                                                                                           // 4
        type: String,                                                                                                 // 5
        label: "Text"                                                                                                 // 6
    },                                                                                                                // 4
    authorId: {                                                                                                       // 8
        type: String                                                                                                  // 9
    },                                                                                                                // 8
    date: {                                                                                                           // 11
        type: Date,                                                                                                   // 12
        autoValue: function autoValue() {                                                                             // 13
            return new Date();                                                                                        // 14
        }                                                                                                             // 15
    }                                                                                                                 // 11
                                                                                                                      //
});                                                                                                                   // 3
                                                                                                                      //
postSchema = new SimpleSchema({                                                                                       // 20
    title: {                                                                                                          // 21
        type: String,                                                                                                 // 22
        label: "Title"                                                                                                // 23
    },                                                                                                                // 21
    text: {                                                                                                           // 25
        type: String,                                                                                                 // 26
        label: "Text"                                                                                                 // 27
    },                                                                                                                // 25
    authorId: {                                                                                                       // 29
        type: String                                                                                                  // 30
    },                                                                                                                // 29
    date: {                                                                                                           // 32
        type: Date,                                                                                                   // 33
        defaultValue: function defaultValue() {                                                                       // 34
            return new Date();                                                                                        // 35
        }                                                                                                             // 36
    },                                                                                                                // 32
    comments: {                                                                                                       // 38
        type: [Comment]                                                                                               // 39
    }                                                                                                                 // 38
});                                                                                                                   // 20
                                                                                                                      //
Posts.attachSchema(postSchema);                                                                                       // 43
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/comments.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/*                                                                                                                    //
export const Comments = new Mongo.Collection('Comments');                                                             //
                                                                                                                      //
Comment = new SimpleSchema({                                                                                          //
    text: {                                                                                                           //
        type: String,                                                                                                 //
        label: "Text"                                                                                                 //
    },                                                                                                                //
    authorId: {                                                                                                       //
        type: String,                                                                                                 //
    },                                                                                                                //
    date: {                                                                                                           //
      type: Date,                                                                                                     //
      autoValue: function() {                                                                                         //
  			return new Date()                                                                                                //
  		},                                                                                                                //
    }                                                                                                                 //
                                                                                                                      //
});                                                                                                                   //
                                                                                                                      //
Comments.attachSchema(Comment);                                                                                       //
*/                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"instructor.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/instructor.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Instructor:function(){return Instructor}});var Instructor = new Mongo.Collection('Instructor');        // 1
                                                                                                                      //
var InstructorSchema = new SimpleSchema({                                                                             // 3
    name: {                                                                                                           // 4
        type: String,                                                                                                 // 5
        label: 'Name'                                                                                                 // 6
    },                                                                                                                // 4
    picture: {                                                                                                        // 8
        type: String,                                                                                                 // 9
        label: 'Profile Picture'                                                                                      // 10
    },                                                                                                                // 8
    strengths: {                                                                                                      // 12
        type: [String],                                                                                               // 13
        label: 'Strengths'                                                                                            // 14
    },                                                                                                                // 12
    description: {                                                                                                    // 16
        type: String,                                                                                                 // 17
        label: 'Description'                                                                                          // 18
    },                                                                                                                // 16
    email: {                                                                                                          // 20
        type: String,                                                                                                 // 21
        label: 'Email'                                                                                                // 22
    },                                                                                                                // 20
    userId: {                                                                                                         // 24
        type: String,                                                                                                 // 25
        label: 'userId'                                                                                               // 26
    }                                                                                                                 // 24
});                                                                                                                   // 3
Instructor.attachSchema(InstructorSchema);                                                                            // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"profiles.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/profiles.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// placeholder                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"student.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/student.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});                                               // 1
Student = new Mongo.Collection('Student');                                                                            // 2
                                                                                                                      //
var AssignmentsSchema = new SimpleSchema({                                                                            // 4
    name: {                                                                                                           // 5
        type: String,                                                                                                 // 6
        label: 'Name'                                                                                                 // 7
    },                                                                                                                // 5
    dateAssigned: {                                                                                                   // 9
        type: Date,                                                                                                   // 10
        label: 'Date'                                                                                                 // 11
    },                                                                                                                // 9
    dueDate: {                                                                                                        // 13
        type: Date,                                                                                                   // 14
        label: 'Due Date'                                                                                             // 15
    },                                                                                                                // 13
    possiblePoints: {                                                                                                 // 17
        type: Number,                                                                                                 // 18
        label: 'Possible Points'                                                                                      // 19
    },                                                                                                                // 17
    pointsRecieved: {                                                                                                 // 21
        type: Number,                                                                                                 // 22
        label: 'Points Recieved'                                                                                      // 23
    },                                                                                                                // 21
    instructor: {                                                                                                     // 25
        type: String,                                                                                                 // 26
        label: 'Instructor'                                                                                           // 27
    }                                                                                                                 // 25
});                                                                                                                   // 4
                                                                                                                      //
var Address = new SimpleSchema({                                                                                      // 31
    street: {                                                                                                         // 32
        type: String,                                                                                                 // 33
        label: 'Address'                                                                                              // 34
    },                                                                                                                // 32
    city: {                                                                                                           // 36
        type: String,                                                                                                 // 37
        label: 'City'                                                                                                 // 38
    },                                                                                                                // 36
    state: {                                                                                                          // 40
        type: String,                                                                                                 // 41
        label: 'String'                                                                                               // 42
    },                                                                                                                // 40
    zipCode: {                                                                                                        // 44
        type: Number,                                                                                                 // 45
        label: 'Zip Code'                                                                                             // 46
    }                                                                                                                 // 44
});                                                                                                                   // 31
                                                                                                                      //
var StudentSchema = new SimpleSchema({                                                                                // 50
    name: {                                                                                                           // 51
        type: String,                                                                                                 // 52
        label: 'Name'                                                                                                 // 53
    },                                                                                                                // 51
    age: {                                                                                                            // 55
        type: Number,                                                                                                 // 56
        label: 'Age'                                                                                                  // 57
    },                                                                                                                // 55
    strengths: {                                                                                                      // 59
        type: [String],                                                                                               // 60
        label: 'Strengths'                                                                                            // 61
    },                                                                                                                // 59
    description: {                                                                                                    // 63
        type: String,                                                                                                 // 64
        label: 'Description'                                                                                          // 65
    },                                                                                                                // 63
    grade: {                                                                                                          // 67
        type: String,                                                                                                 // 68
        label: 'Grade'                                                                                                // 69
    },                                                                                                                // 67
    attendance: {                                                                                                     // 71
        type: [Boolean],                                                                                              // 72
        label: 'Attendance'                                                                                           // 73
    },                                                                                                                // 71
    assignments: {                                                                                                    // 75
        type: [AssignmentsSchema],                                                                                    // 76
        label: 'Assignments'                                                                                          // 77
    },                                                                                                                // 75
    school: {                                                                                                         // 79
        type: String,                                                                                                 // 80
        label: 'School'                                                                                               // 81
    },                                                                                                                // 79
    email: {                                                                                                          // 83
        type: String,                                                                                                 // 84
        label: 'Email'                                                                                                // 85
    },                                                                                                                // 83
    getHipYear: {                                                                                                     // 87
        type: Number,                                                                                                 // 88
        label: 'Get Hip Year'                                                                                         // 89
    },                                                                                                                // 87
    phoneNumber: {                                                                                                    // 91
        type: Number,                                                                                                 // 92
        label: 'Phone Number'                                                                                         // 93
    },                                                                                                                // 91
    parentNames: {                                                                                                    // 95
        type: [String],                                                                                               // 96
        label: 'Parent\'s Phone Numbers'                                                                              // 97
    },                                                                                                                // 95
    address: {                                                                                                        // 99
        type: Address,                                                                                                // 100
        label: 'Home Address'                                                                                         // 101
    },                                                                                                                // 99
    github: {                                                                                                         // 103
        type: String, //The string can be their user name. Using that we can generate a URL to their github profile   // 104
        label: 'Github'                                                                                               // 105
    },                                                                                                                // 103
    tshirtSize: {                                                                                                     // 107
        type: String,                                                                                                 // 108
        label: 'tshirtSize'                                                                                           // 109
    },                                                                                                                // 107
    blog: {                                                                                                           // 111
        type: String,                                                                                                 // 112
        label: "Blog"                                                                                                 // 113
    },                                                                                                                // 111
    ep10: {                                                                                                           // 115
        type: [String],                                                                                               // 116
        label: "EP10"                                                                                                 // 117
    },                                                                                                                // 115
    userId: {                                                                                                         // 119
        type: String,                                                                                                 // 120
        label: 'userId'                                                                                               // 121
    },                                                                                                                // 119
    picture: {                                                                                                        // 123
        type: String,                                                                                                 // 124
        label: 'Profile Picture'                                                                                      // 125
    }                                                                                                                 // 123
});                                                                                                                   // 50
Student.attachSchema(StudentSchema);                                                                                  // 128
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"main.js":["meteor/meteor","../collections/blogPosts.js","../collections/comments.js","../collections/assignments.js","../collections/instructor.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Posts;module.import('../collections/blogPosts.js',{"Posts":function(v){Posts=v}});var Comments;module.import('../collections/comments.js',{"Comments":function(v){Comments=v}});var Assignments;module.import('../collections/assignments.js',{"Assignments":function(v){Assignments=v}});var Instructor;module.import('../collections/instructor.js',{"Instructor":function(v){Instructor=v}});// Import meteor for server / publish and Assignments to publish
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      // 6
                                                                                                                      //
function _createDefaultUser() {                                                                                       // 8
	var users = Meteor.users.find({ username: "admin" }).fetch();                                                        // 9
	if (users.length > 0) {                                                                                              // 10
		return;                                                                                                             // 11
	}                                                                                                                    // 12
                                                                                                                      //
	var adminId = Accounts.createUser({                                                                                  // 14
		username: "admin",                                                                                                  // 15
		password: "Gallup2016"                                                                                              // 16
	});                                                                                                                  // 14
	Roles.addUsersToRoles(adminId, ['instructor']);                                                                      // 18
	Instructor.insert({                                                                                                  // 19
		name: "admin",                                                                                                      // 20
		profilePicture: "none",                                                                                             // 21
		strengths: ["Achiever", "Activator", "Analytical", "Arranger", "Competition"],                                      // 22
		description: "Admin. I validate other users.",                                                                      // 23
		email: "none",                                                                                                      // 24
		userId: adminId                                                                                                     // 25
	});                                                                                                                  // 19
}                                                                                                                     // 27
                                                                                                                      //
// Publishes Assignments collection so templates can subscribe to recieve collection data                             //
Meteor.startup(function () {                                                                                          // 30
	// code to run on server at startup                                                                                  //
	var path = Meteor.settings.uploadDirectoryPath;                                                                      // 32
                                                                                                                      //
	UploadServer.init({                                                                                                  // 34
		tmpDir: (process.env.PWD || process.cwd()) + path + 'tmp/',                                                         // 35
		uploadDir: (process.env.PWD || process.cwd()) + path,                                                               // 36
		checkCreateDirectories: true,                                                                                       // 37
		finished: function finished(fileInfo, formFields) {                                                                 // 38
			console.log(fileInfo);                                                                                             // 39
			console.log(formFields);                                                                                           // 40
                                                                                                                      //
			var fs = Npm.require('fs');                                                                                        // 42
                                                                                                                      //
			var fileTypes = ['image/gif', 'image/jpg', 'image/jpeg', 'image/png', 'image/svg+xml'];                            // 44
			var fileExtensions = ['.gif', '.jpg', '.jpeg', '.png', '.svg'];                                                    // 45
                                                                                                                      //
			var extension;                                                                                                     // 47
                                                                                                                      //
			for (var i in fileTypes) {                                                                                         // 49
				if (fileInfo.type === fileTypes[i]) {                                                                             // 50
					extension = fileExtensions[i];                                                                                   // 51
					console.log(fileExtensions[i]);                                                                                  // 52
				}                                                                                                                 // 53
			}                                                                                                                  // 54
                                                                                                                      //
			Student.update({ _id: formFields.id }, { $set: { picture: formFields.id + extension } });                          // 56
                                                                                                                      //
			fs.rename((process.env.PWD || process.cwd()) + path + fileInfo.name, (process.env.PWD || process.cwd()) + path + formFields.id + extension, function (stuff) {
				console.log((process.env.PWD || process.cwd()) + path + fileInfo.name);                                           // 61
				console.log((process.env.PWD || process.cwd()) + path + formFields.id + extension);                               // 62
				console.log('trying to rename file');                                                                             // 63
				console.log(stuff);                                                                                               // 64
			});                                                                                                                // 65
		},                                                                                                                  // 66
		acceptFileTypes: /(\.|\/)(gif|jpe?g|png|svg)$/i                                                                     // 67
	});                                                                                                                  // 34
                                                                                                                      //
	studentIndex = new EasySearch.Index({                                                                                // 70
		name: "studentIndex",                                                                                               // 71
		collection: Student,                                                                                                // 72
		fields: ['name'],                                                                                                   // 73
		engine: new EasySearch.Minimongo({                                                                                  // 74
			transform: function transform(doc) {                                                                               // 75
				doc.url = "/profile/" + doc._id;                                                                                  // 76
				doc.total = 0;                                                                                                    // 77
				for (i = 0; i < 12; i++) {                                                                                        // 78
					doc.total += doc.attendance[i];                                                                                  // 79
				}                                                                                                                 // 80
				for (i in doc.attendance) {                                                                                       // 81
					if (doc.attendance[i] == true) {                                                                                 // 82
						doc.attendance[i] = "green";                                                                                    // 83
					}                                                                                                                // 84
					if (doc.attendance[i] == false) {                                                                                // 85
						doc.attendance[i] = "red";                                                                                      // 86
					}                                                                                                                // 87
				}                                                                                                                 // 88
				console.log(doc.attendance);                                                                                      // 89
				doc.parentNames = doc.parentNames.join(" and ");                                                                  // 90
				return doc;                                                                                                       // 91
			}                                                                                                                  // 92
		}),                                                                                                                 // 74
		permission: function permission() {                                                                                 // 94
			return true;                                                                                                       // 95
		}                                                                                                                   // 96
	});                                                                                                                  // 70
	Meteor.publish("Comments", function () {                                                                             // 98
		return Comments.find();                                                                                             // 99
	});                                                                                                                  // 100
	Meteor.publish("Posts", function () {                                                                                // 101
		return Posts.find();                                                                                                // 102
	});                                                                                                                  // 103
	Posts.allow({                                                                                                        // 104
		'insert': function insert(userId, doc) {                                                                            // 105
			true;                                                                                                              // 106
		},                                                                                                                  // 107
		'update': function update(userId, doc) {                                                                            // 108
			true;                                                                                                              // 109
		}                                                                                                                   // 110
	});                                                                                                                  // 104
                                                                                                                      //
	Meteor.methods({                                                                                                     // 113
		'insertPost': function insertPost(post) {                                                                           // 114
			Posts.insert(post);                                                                                                // 115
			console.log(Posts.find().fetch());                                                                                 // 116
		},                                                                                                                  // 117
		'updateComment': function updateComment(postId, authorId, commentText) {                                            // 118
			Posts.update({ _id: postId }, { $push: {                                                                           // 119
					comments: { text: commentText,                                                                                   // 121
						authorId: authorId,                                                                                             // 123
						date: new Date() }                                                                                              // 124
				} });                                                                                                             // 120
		},                                                                                                                  // 126
		'testCreatePosts': function testCreatePosts() {                                                                     // 127
			var jimId = Meteor.users.findOne({ username: "jim" })._id;                                                         // 128
			var instructorId = Meteor.users.findOne({ username: "instructor" })._id;                                           // 129
                                                                                                                      //
			var i = 0;                                                                                                         // 131
			var dates = [new Date(2016, 1, 1), new Date(2016, 2, 1), new Date(2016, 3, 1), new Date(2015, 1, 1), new Date(2015, 2, 1), new Date(2015, 3, 1), new Date(2014, 1, 1), new Date(2014, 2, 1), new Date(2014, 3, 1), new Date(2013, 1, 1)];
			console.log(dates);                                                                                                // 144
			for (i = 1; i <= 10; i++) {                                                                                        // 145
				var id = jimId;                                                                                                   // 146
				if (i % 2 == 0) {                                                                                                 // 147
					id = instructorId;                                                                                               // 148
				}                                                                                                                 // 149
				Posts.insert({                                                                                                    // 150
					title: "Title " + i,                                                                                             // 151
					text: "Text of the blog post.\n\n\n\nEnd of blog post.",                                                         // 152
					authorId: id,                                                                                                    // 153
					date: dates[i - 1],                                                                                              // 154
					comments: [{                                                                                                     // 155
						text: "Comment.",                                                                                               // 157
						authorId: "otherId",                                                                                            // 158
						date: dates[i - 1]                                                                                              // 159
					}, {                                                                                                             // 156
						text: "Comment.",                                                                                               // 162
						authorId: "otherId",                                                                                            // 163
						date: dates[i - 1]                                                                                              // 164
					}, {                                                                                                             // 161
						text: "Comment.",                                                                                               // 167
						authorId: "otherId",                                                                                            // 168
						date: dates[i - 1]                                                                                              // 169
					}]                                                                                                               // 166
				});                                                                                                               // 150
			}                                                                                                                  // 173
		},                                                                                                                  // 175
		'testCreateUsers': function testCreateUsers() {                                                                     // 176
			var instructorId = Accounts.createUser({                                                                           // 177
				username: "instructor",                                                                                           // 178
				password: "password"                                                                                              // 179
			});                                                                                                                // 177
			var jimId = Accounts.createUser({                                                                                  // 181
				username: "jim",                                                                                                  // 182
				password: "password"                                                                                              // 183
			});                                                                                                                // 181
			var studentId = Accounts.createUser({                                                                              // 185
				username: "student",                                                                                              // 186
				password: "password"                                                                                              // 187
			});                                                                                                                // 185
                                                                                                                      //
			Roles.addUsersToRoles(instructorId, 'instructor');                                                                 // 190
			Roles.addUsersToRoles(jimId, 'instructor');                                                                        // 191
			Roles.addUsersToRoles(studentId, 'student');                                                                       // 192
                                                                                                                      //
			Instructor.insert({                                                                                                // 194
				"name": "Jim Collison",                                                                                           // 195
				"profilePicture": "x",                                                                                            // 196
				"strengths": ['Arranger', 'Woo', 'Communication', 'Maximizer', 'Activator'],                                      // 197
				"description": "Teacher",                                                                                         // 198
				"email": "Teacher@teacher.com",                                                                                   // 199
				"userId": jimId                                                                                                   // 200
			});                                                                                                                // 194
			Instructor.insert({                                                                                                // 202
				"name": "Zach",                                                                                                   // 203
				"profilePicture": "x",                                                                                            // 204
				"strengths": ['Arranger', 'Woo', 'Communication', 'Maximizer', 'Activator'],                                      // 205
				"description": "Teacher",                                                                                         // 206
				"email": "Teacher@teacher.com",                                                                                   // 207
				"userId": instructorId                                                                                            // 208
			});                                                                                                                // 202
			Student.insert({                                                                                                   // 210
				"name": "Johnny",                                                                                                 // 211
				"profilePicture": "x",                                                                                            // 212
				"age": 15,                                                                                                        // 213
				"strengths": ['Input', 'Command', 'Restorative', 'Learner', 'Futuristic'],                                        // 214
				"description": "tall",                                                                                            // 215
				"grade": '10th',                                                                                                  // 216
				"attendance": [true, false, true, true, false, false, true, true, false, true, true, false],                      // 217
				"assignments": [{                                                                                                 // 220
					"name": "Java Work",                                                                                             // 221
					"dateAssigned": new Date(),                                                                                      // 222
					"dueDate": new Date(),                                                                                           // 223
					"possiblePoints": 100,                                                                                           // 224
					"pointsRecieved": 10,                                                                                            // 225
					"instructor": "Zach"                                                                                             // 226
				}, {                                                                                                              // 220
					name: "Java Work",                                                                                               // 228
					dateAssigned: new Date(),                                                                                        // 229
					dueDate: new Date(),                                                                                             // 230
					possiblePoints: 100,                                                                                             // 231
					pointsRecieved: 10,                                                                                              // 232
					instructor: "Zach"                                                                                               // 233
				}],                                                                                                               // 227
				"school": "West Dodge",                                                                                           // 235
				"email": "ben@ben.com",                                                                                           // 236
				"getHipYear": 2,                                                                                                  // 237
				"phoneNumber": '4026571179',                                                                                      // 238
				"parentNames": ['Bill', 'Hillary'],                                                                               // 239
				"address": {                                                                                                      // 240
					"street": '3910 s 226th st.',                                                                                    // 241
					"city": 'Elkhorn',                                                                                               // 242
					"state": 'Nebraska',                                                                                             // 243
					"zipCode": 68022                                                                                                 // 244
				},                                                                                                                // 240
				"github": 'Athletesrun',                                                                                          // 246
				"blog": "http://blogger.com",                                                                                     // 247
				"tshirtSize": "Small",                                                                                            // 248
				"ep10": ["Responsibility", "Profitability", "Communication", "Strategic"],                                        // 249
				"userId": studentId                                                                                               // 250
			});                                                                                                                // 210
		},                                                                                                                  // 252
		'createDefaultUser': function createDefaultUser() {                                                                 // 253
			_createDefaultUser();                                                                                              // 254
		}                                                                                                                   // 255
	});                                                                                                                  // 113
	Meteor.publish('Assignments', function () {                                                                          // 257
		return Assignments.find();                                                                                          // 258
	});                                                                                                                  // 259
                                                                                                                      //
	Meteor.publish("Student", function () {                                                                              // 261
		return Student.find();                                                                                              // 262
	});                                                                                                                  // 263
	Meteor.publish("Teacher", function () {                                                                              // 264
		return Teacher.find();                                                                                              // 265
	});                                                                                                                  // 266
	//control update better                                                                                              //
	Student.allow({                                                                                                      // 268
		update: function update(userId, doc) {                                                                              // 269
			return true;                                                                                                       // 270
		}                                                                                                                   // 271
	});                                                                                                                  // 268
                                                                                                                      //
	Student.remove({});                                                                                                  // 274
	Instructor.remove({});                                                                                               // 275
	for (var i = Student.find().count(); i < 5; i++) {                                                                   // 276
		Student.insert({                                                                                                    // 277
			"name": "Dash Wedergren " + i,                                                                                     // 278
			"userId": "as879",                                                                                                 // 279
			"age": 16,                                                                                                         // 280
			"strengths": ['Input', 'Command', 'Restorative', 'Learner', 'Futuristic'],                                         // 281
			"description": "Programmer",                                                                                       // 282
			"grade": '10',                                                                                                     // 283
			"attendance": [true, false, true, true, false, false, true, true, false, true, true, false],                       // 284
			"assignments": [{                                                                                                  // 287
				"name": "Java Work",                                                                                              // 288
				"dateAssigned": new Date(),                                                                                       // 289
				"dueDate": new Date(),                                                                                            // 290
				"possiblePoints": 100,                                                                                            // 291
				"pointsRecieved": 10,                                                                                             // 292
				"instructor": "Zach"                                                                                              // 293
			}, {                                                                                                               // 287
				name: "Java Work",                                                                                                // 295
				dateAssigned: new Date(),                                                                                         // 296
				dueDate: new Date(),                                                                                              // 297
				possiblePoints: 100,                                                                                              // 298
				pointsRecieved: 10,                                                                                               // 299
				instructor: "Zach"                                                                                                // 300
			}],                                                                                                                // 294
			"school": "Mount Michael",                                                                                         // 302
			"email": "dash_wedergren@gallup.com",                                                                              // 303
			"getHipYear": 2,                                                                                                   // 304
			"phoneNumber": '4026571179',                                                                                       // 305
			"parentNames": ['Bill', 'Hillary'],                                                                                // 306
			"address": {                                                                                                       // 307
				"street": '3910 s 226th st.',                                                                                     // 308
				"city": 'Elkhorn',                                                                                                // 309
				"state": 'Nebraska',                                                                                              // 310
				"zipCode": 68022                                                                                                  // 311
			},                                                                                                                 // 307
			"github": 'Athletesrun',                                                                                           // 313
			"blog": "http://blogger.com",                                                                                      // 314
			"tshirtSize": "Small",                                                                                             // 315
			"ep10": ["Responsibility", "Profitability", "Communication", "Strategic"],                                         // 316
			"picture": '8710339dcb6814d0d9d2290ef422285c9322b7163951f9a0ca8f883d3305286f44139aa374848e4174f5aada663027e4548637b6d19894aec4fb6c46a139fbf9.jpg'
		});                                                                                                                 // 277
	}                                                                                                                    // 319
	for (var i = Instructor.find().count(); i < 5; i++) {                                                                // 320
		Instructor.insert({                                                                                                 // 321
			"name": "Zach Merrill " + i,                                                                                       // 322
			"userId": "ad89",                                                                                                  // 323
			"strengths": ['Command', 'Relator', 'Analytical', 'Learner', 'Responsibility'],                                    // 324
			"description": "Teacher",                                                                                          // 325
			"email": "zach_merrill@gallup.com",                                                                                // 326
			"picture": '8710339dcb6814d0d9d2290ef422285c9322b7163951f9a0ca8f883d3305286f44139aa374848e4174f5aada663027e4548637b6d19894aec4fb6c46a139fbf9.jpg'
		});                                                                                                                 // 321
	}                                                                                                                    // 329
	console.log(Student.findOne({                                                                                        // 330
		"name": "Dash Wedergren 1"                                                                                          // 331
	}));                                                                                                                 // 330
	console.log(Instructor.findOne({                                                                                     // 333
		"name": "Zach Merrill 1"                                                                                            // 334
	}));                                                                                                                 // 333
	_createDefaultUser();                                                                                                // 336
});                                                                                                                   // 337
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/routes.js");
require("./collections/assignments.js");
require("./collections/blogPosts.js");
require("./collections/comments.js");
require("./collections/instructor.js");
require("./collections/profiles.js");
require("./collections/student.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
